// Dependencies
var gulp = require('gulp');
var sass = require('gulp-sass');
//var gutil = require('gulp-util');
var concat = require('gulp-concat');
var uglify = require('gulp-uglify');
var gzip = require('gulp-gzip');
var notify = require('gulp-notify');
var cssbeautify = require('gulp-cssbeautify');
var mmq = require('gulp-merge-media-queries');


// Extension Configurations
var jgzconfig = {
    extension: 'jgz'
};

var csgzconfig = {
    extension: 'csgz'
};

// File Paths
var paths = {
    destination: './html/assets/',
    js: [
        './html/assets/source/js/*.js'
    ],
    scss: [
        './html/assets/source/scss/custom.scss',
    ],
    watchScss: [
        './html/assets/source/scss/custom.scss',
    ]
};

function compileJS(cb) {
    gulp.src(paths.js)
        //.pipe(uglify())
        .pipe(concat('scripts.js'))
        .pipe(gulp.dest('./html/assets/js'))
        .pipe(gzip(jgzconfig))
        //.pipe(concat('scripts'))
        // .pipe(gulp.dest('./html/assets/js'))
        .pipe(notify({
            message: "JS processed"
        }));

    cb();
}

function compileSCSS(cb) {
    gulp.src(paths.scss)
        .pipe(sass({
            outputStyle: 'compressed',
            sourceComments: false
        }).on('error', sass.logError))
        .pipe(concat('screen.css'))
        // condense our media queries down
        //.pipe(mmq())
        //.pipe(cssbeautify())
        .pipe(gulp.dest('./html/assets/css'))
        .pipe(concat('screen'))
        .pipe(gzip(csgzconfig))
        .pipe(gulp.dest('./html/assets/css'))
        //.pipe(gulp.dest('./html/assets/css'))

    .pipe(notify({
        message: "SCSS processed"
    }));

    cb();
}

// Watchers
gulp.watch(paths.js, compileJS);
gulp.watch(paths.watchScss, compileSCSS);
exports.default = gulp.parallel(compileJS, compileSCSS);