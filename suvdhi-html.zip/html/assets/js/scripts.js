// when the page is ready, initialize everything
jQuery(document).ready(function() {
    jQuery(".scroll-bottom-icon").click(function() {
        jQuery('html, body').animate({
            scrollTop: jQuery("#scroll-bottom-footer").offset().top
        }, 1500);

    });
});