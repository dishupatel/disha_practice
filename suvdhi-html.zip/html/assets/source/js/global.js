// when the page is ready, initialize everything
jQuery(document).on('ready', function() {

});